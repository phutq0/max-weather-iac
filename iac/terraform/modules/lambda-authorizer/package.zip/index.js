exports.handler = async (event) => {
  console.log('Lambda authorizer invoked with event:', JSON.stringify(event, null, 2));
  
  try {
    const token = (event.authorizationToken || '').replace(/^Bearer\s+/i, '');
    
    if (!token) {
      console.log('No token provided');
      return {
        principalId: 'anonymous',
        policyDocument: {
          Version: '2012-10-17',
          Statement: [
            {
              Action: 'execute-api:Invoke',
              Effect: 'Deny',
              Resource: event.methodArn,
            },
          ],
        },
      };
    }

    // For testing purposes, accept any non-empty token
    console.log('Token received:', token);
    
    return {
      principalId: 'test-user',
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: 'execute-api:Invoke',
            Effect: 'Allow',
            Resource: event.methodArn,
          },
        ],
      },
      context: {
        sub: 'test-user',
        scope: 'read:weather',
      },
    };
  } catch (err) {
    console.error('Auth error:', err);
    return {
      principalId: 'error',
      policyDocument: {
        Version: '2012-10-17',
        Statement: [
          {
            Action: 'execute-api:Invoke',
            Effect: 'Deny',
            Resource: event.methodArn,
          },
        ],
      },
    };
  }
};